/* Craft Pulse's browser UI adapter for the supplied LocalLoop Firebase API. */
const ui = window.MadeNearbyPrototype;
let api;
let firebaseConfigured = false;
let authActionBusy = false;
let pendingSession = null;
let activeUid = null;
let unsubscribers = [];
let reviewUnsubscribers = [];
let cloudProviders = [];
let customerOrders = [];
let makerOrders = [];
let currentLocation = null;
let setupMessage = "Firebase is not configured. The prototype is running with local demo data.";

if (!ui) {
  console.error("Craft Pulse UI bridge was not found.");
} else {
  // These listeners are installed before Firebase loads so a configured app
  // never accidentally submits a real action to the browser-only demo code.
  document.addEventListener("submit", handleSubmit, true);
  document.addEventListener("click", handleClick, true);
  document.addEventListener("change", handleChange, true);

  try {
    const settings = await import("../firebase-config.js");
    const config = settings.firebaseConfig || {};
    const required = ["apiKey", "authDomain", "projectId", "appId"];
    firebaseConfigured = required.every((key) => typeof config[key] === "string" && config[key].trim());
    if (!firebaseConfigured) {
      setupMessage = "No Firebase web-app settings are filled in. Demo mode remains available.";
      ui.setBackendMode(false);
      ui.setBackendStatus("Demo mode · Firebase setup needed", setupMessage);
    } else {
      setupMessage = "Firebase web-app settings were found. Sign in to load your live data.";
      ui.setBackendMode(true);
      ui.setBackendStatus("Connecting to Firebase…", "Connecting to your Firebase project.");
      const { bootstrapLocalLoopBackend } = await import("./bootstrap.js");
      api = bootstrapLocalLoopBackend({
        firebaseConfig: config,
        functionsRegion: settings.functionsRegion || "asia-south1",
      });
      observeAuth();
      installUiEnhancements();
      new MutationObserver(installUiEnhancements).observe(document.body, { childList: true, subtree: true });
    }
  } catch (error) {
    firebaseConfigured = false;
    setupMessage = readableError(error);
    ui.setBackendMode(false);
    ui.setBackendStatus("Firebase setup needs attention", readableError(error));
    console.error("Firebase could not be started:", error);
  }
}

function observeAuth() {
  api.auth.observeSession((session) => {
    if (authActionBusy) {
      pendingSession = session;
      return;
    }
    void handleAuthSession(session);
  }, (error) => {
    ui.setBackendStatus("Firebase connection issue", readableError(error));
    ui.notify(readableError(error));
  });
}

async function handleAuthSession(session) {
  const uid = session?.uid || null;
  if (!uid) {
    activeUid = null;
    stopLiveData();
    ui.setBackendSession(null);
    ui.setBackendMakers([]);
    ui.setBackendOrders([]);
    ui.setBackendSaved([]);
    setupMessage = "Your Firebase project is connected. Sign in to load live records.";
    ui.setBackendStatus("Firebase ready · sign in", setupMessage);
    return;
  }
  if (activeUid === uid) return;
  try {
    const profile = await api.users.getMine();
    await activateUser(profile);
  } catch (error) {
    ui.setBackendStatus("Could not load your profile", readableError(error));
    ui.notify(`Could not load your account: ${readableError(error)}`);
  }
}

async function activateUser(profile) {
  activeUid = profile.id;
  setupMessage = `Signed in as ${profile.email || profile.name || "Firebase user"}. Live records update in real time.`;
  ui.setBackendSession(profile);
  ui.setBackendSaved(profile.savedMakers || []);
  ui.setBackendMakers([]);
  ui.setBackendOrders([]);
  ui.setBackendStatus("Connected · live Firebase data", "Your account, makers, orders and reviews use the supplied Firebase backend.");
  stopLiveData();

  const onError = (error) => {
    ui.setBackendStatus("Live data needs attention", readableError(error));
    ui.notify(readableError(error));
  };
  unsubscribers.push(api.discovery.subscribe({ limit: 100 }, (providers) => {
    cloudProviders = providers;
    refreshMakers();
  }, onError));
  unsubscribers.push(api.orders.subscribeCustomerOrders((orders) => {
    customerOrders = orders.map(mapOrder);
    refreshOrders();
  }, onError));
  unsubscribers.push(api.orders.subscribeMakerOrders((orders) => {
    makerOrders = orders.map(mapOrder);
    refreshOrders();
  }, onError));
}

function stopLiveData() {
  [...unsubscribers, ...reviewUnsubscribers].forEach((unsubscribe) => {
    try { unsubscribe(); } catch { /* A stopped listener is already harmless. */ }
  });
  unsubscribers = [];
  reviewUnsubscribers = [];
  cloudProviders = [];
  customerOrders = [];
  makerOrders = [];
}

function refreshMakers() {
  ui.setBackendMakers(cloudProviders.map((provider) => toMaker(provider)));
}

function subscribeMakerReviews(providerId) {
  reviewUnsubscribers.forEach((unsubscribe) => unsubscribe());
  reviewUnsubscribers = [];
  if (!providerId || !api) return;
  reviewUnsubscribers.push(api.reviews.subscribeForProvider(providerId, (reviews) => {
    const current = cloudProviders.find((item) => item.id === providerId);
    if (!current) return;
    current.recentReviews = reviews.slice(0, 5).map((review) => ({
      name: "Neighbour",
      rating: review.rating,
      text: review.text || "Verified review",
    }));
    refreshMakers();
  }, (error) => console.warn("Could not load maker reviews:", readableError(error))));
}

function refreshOrders() {
  const byId = new Map();
  [...customerOrders, ...makerOrders].forEach((order) => byId.set(order.id, order));
  ui.setBackendOrders([...byId.values()].sort((a, b) => b.created - a.created));
}

function toMaker(provider) {
  const labels = { tailoring: "Tailoring", footwear: "Footwear repair", cakes: "Cakes", carpentry: "Carpentry" };
  const categoryId = String(provider.categoryId || "maker");
  const craft = labels[categoryId] || categoryId.replace(/[-_]/g, " ").replace(/\b\w/g, (x) => x.toUpperCase());
  const rating = provider.ratingCount ? provider.ratingSum / provider.ratingCount : 0;
  const locationText = Number.isFinite(provider.lat) && Number.isFinite(provider.lng)
    ? `${provider.lat.toFixed(5)}, ${provider.lng.toFixed(5)}`
    : "Location not set";
  return {
    id: provider.id,
    owner: provider.ownerId || provider.id,
    name: provider.shopName,
    craft,
    categoryId: provider.categoryId,
    desc: "Independent local maker · see listed services and rates below.",
    phone: provider.phone,
    lat: provider.lat,
    lng: provider.lng,
    locationText,
    services: provider.services || [],
    workingHours: provider.workingHours || [],
    workers: provider.workers || 1,
    paused: !!provider.isPaused,
    queue: provider.queueCount || 0,
    queueCount: provider.queueCount || 0,
    queueClearsAt: provider.queueClearsAt ? Date.parse(provider.queueClearsAt) : null,
    rating,
    reviews: provider.ratingCount || 0,
    recentReviews: provider.recentReviews || [],
    movedAt: provider.movedAt ? Date.parse(provider.movedAt) : null,
    firebaseProvider: true,
    distance: currentLocation ? distanceKm(currentLocation, provider) : null,
    x: 20 + hash(provider.id) % 62,
    y: 24 + hash(provider.id + "map") % 56,
  };
}

function mapOrder(order) {
  const created = Date.parse(order.createdAt) || Date.now();
  const readyAt = order.estReadyAt ? Date.parse(order.estReadyAt) : (order.readyAt ? Date.parse(order.readyAt) : null);
  return {
    id: order.id,
    maker: order.providerId,
    customer: order.customerId,
    customerName: order.customerName || "Neighbour",
    service: order.service,
    note: order.details?.notes || "",
    date: order.details?.dateNeeded || "Date to be confirmed",
    status: order.status,
    created,
    acceptedAt: Date.parse(order.startedAt || order.updatedAt) || created,
    startedAt: order.startedAt ? Date.parse(order.startedAt) : null,
    readyAt,
    serviceMinutes: order.serviceMinutes || 0,
    estimatedMinutes: order.serviceMinutes || 0,
    amount: order.quotePrice || 0,
    quote: order.quotePrice,
    eta: order.quoteTime ? `${order.quoteTime.value} ${order.quoteTime.unit}` : "",
    reviewed: false,
    firebaseOrder: true,
  };
}

async function handleSubmit(event) {
  const form = event.target.closest("form[data-form]");
  if (!firebaseConfigured || !form) return;
  const type = form.dataset.form;
  if (["login", "signup", "maker", "order", "review", "kyc"].includes(type)) {
    event.preventDefault();
    event.stopImmediatePropagation();
  } else if (type === "payment") {
    event.preventDefault();
    event.stopImmediatePropagation();
    ui.notify("Payments are not included in this backend yet.");
    return;
  } else {
    return;
  }

  if (type === "kyc") {
    ui.notify("The supplied backend has no KYC or identity-document endpoint yet. This request was not saved.");
    return;
  }
  if (type === "login" || type === "signup") return handleAuthSubmit(type, form);
  if (!api) return ui.notify("Firebase is still connecting. Please try again in a moment.");
  if (!activeUid) return ui.notify("Sign in first to use the live database.");
  if (type === "maker") return handleMakerSubmit(form);
  if (type === "order") return handleOrderSubmit(form);
  if (type === "review") return handleReviewSubmit(form);
}

async function handleAuthSubmit(type, form) {
  if (!api) return ui.notify("Firebase is not ready. Check the setup panel.");
  const data = new FormData(form);
  authActionBusy = true;
  try {
    const result = type === "signup"
      ? await api.auth.signUpEmail({ name: data.get("name"), email: data.get("email"), password: data.get("password") })
      : await api.auth.signInEmail({ email: data.get("email"), password: data.get("password") });
    pendingSession = null;
    await activateUser(result.user);
    ui.notify(type === "signup" ? "Your Firebase account is ready." : `Welcome back, ${(result.user.name || "neighbour").split(" ")[0]}.`);
  } catch (error) {
    ui.notify(readableError(error));
  } finally {
    authActionBusy = false;
    pendingSession = null;
  }
}

async function handleMakerSubmit(form) {
  const data = new FormData(form);
  const lat = Number(data.get("latitude"));
  const lng = Number(data.get("longitude"));
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    ui.notify("Use the location button first so the backend can save your shop pin.");
    return;
  }
  const craftIds = { "Tailoring": "tailoring", "Footwear repair": "footwear", "Cakes": "cakes", "Carpentry": "carpentry" };
  const categoryId = craftIds[String(data.get("craft"))];
  if (!categoryId) return ui.notify("This craft is not set up in the backend categories yet.");
  const serviceText = String(data.get("service") || "").trim();
  const priceMatch = serviceText.match(/[₹$]?\s*([0-9][0-9,]*(?:\.\d{1,2})?)\s*$/);
  const price = priceMatch ? Number(priceMatch[1].replace(/,/g, "")) : null;
  const serviceName = priceMatch ? serviceText.slice(0, priceMatch.index).replace(/[·|–—-]\s*$/, "").trim() : serviceText;
  const open = String(data.get("open") || "09:00");
  const close = String(data.get("close") || "18:00");
  const openDays = new Set([...form.querySelectorAll("[name=\"openDays\"]:checked")].map((input) => Number(input.value)));
  if (!serviceName || openDays.size === 0) return ui.notify("Add a service and select at least one working day.");
  const workingHours = Array.from({ length: 7 }, (_, day) => openDays.has(day) ? { open, close } : null);
  try {
    const provider = await api.providers.completeOnboarding({
      shopName: String(data.get("name")).trim(),
      categoryId,
      phone: String(data.get("phone")).trim(),
      lat,
      lng,
      services: [{ name: serviceName, price, avgTime: Number(data.get("avgTime")) || 1, unit: String(data.get("unit") || "hours") }],
      workingHours,
      workers: Number(data.get("workers")) || 1,
    });
    const profile = await api.users.getMine();
    await activateUser(profile);
    ui.notify(`Maker profile ${provider.shopName} is live.`);
    document.querySelector('[data-page="maker"]')?.click();
  } catch (error) {
    ui.notify(readableError(error));
  }
}

async function handleOrderSubmit(form) {
  const data = new FormData(form);
  try {
    await api.orders.create({
      providerId: String(data.get("maker")),
      service: String(data.get("service")),
      details: {
        materialsBy: String(data.get("materialsBy") || "Customer"),
        notes: String(data.get("note") || "").trim(),
        dateNeeded: String(data.get("date") || ""),
      },
    });
    window.closeModal?.();
    document.querySelector('[data-page="orders"]')?.click();
    ui.notify("Request sent to the maker. Your orders will update live.");
  } catch (error) {
    ui.notify(readableError(error));
  }
}

async function handleReviewSubmit(form) {
  const data = new FormData(form);
  try {
    const text = String(data.get("text") || "").trim();
    await api.reviews.create({ orderId: String(data.get("orderId")), rating: Number(data.get("rating")), ...(text ? { text } : {}) });
    ui.notify("Verified review saved.");
  } catch (error) {
    ui.notify(readableError(error));
  }
}

async function handleClick(event) {
  const button = event.target.closest("button, a");
  if (!firebaseConfigured || !button) return;
  if (button.dataset.demo) {
    event.preventDefault(); event.stopImmediatePropagation();
    ui.notify("Demo accounts are disabled while Firebase is configured. Sign in with your account instead.");
    return;
  }
  if (button.dataset.removePhoto !== undefined) {
    event.preventDefault(); event.stopImmediatePropagation();
    ui.notify("Photo removal is not connected to cloud storage yet.");
    return;
  }
  if (button.dataset.profile) setTimeout(() => subscribeMakerReviews(button.dataset.profile), 0);
  if (button.dataset.action === "database") {
    event.preventDefault(); event.stopImmediatePropagation(); showSetupPanel(); return;
  }
  if (!api) return;
  if (button.dataset.action === "pin") {
    event.preventDefault(); event.stopImmediatePropagation(); await getCurrentLocation(button, "Shop location saved for this form."); return;
  }
  if (button.dataset.action === "location") {
    event.preventDefault(); event.stopImmediatePropagation(); await getCurrentLocation(button, "Location ready. Maker distances now use your device location."); return;
  }
  if (button.dataset.action === "logout" || button.hasAttribute("data-confirm-logout")) {
    event.preventDefault(); event.stopImmediatePropagation();
    if (button.hasAttribute("data-confirm-logout")) {
      authActionBusy = true;
      try { await api.auth.signOut(); deactivateUser(); }
      catch (error) { ui.notify(readableError(error)); }
      finally { authActionBusy = false; pendingSession = null; }
      return;
    }
    authActionBusy = true;
    try { await api.auth.signOut(); deactivateUser(); }
    catch (error) { ui.notify(readableError(error)); }
    finally { authActionBusy = false; pendingSession = null; }
    return;
  }
  if (button.dataset.save) {
    event.preventDefault(); event.stopImmediatePropagation();
    if (!activeUid) return ui.notify("Sign in to save makers to your account.");
    const saved = new Set(ui.currentUser()?.savedMakers || []);
    saved.has(button.dataset.save) ? saved.delete(button.dataset.save) : saved.add(button.dataset.save);
    try {
      const result = await api.users.updateSavedMakers([...saved]);
      ui.setBackendSaved(result.savedMakers || [...saved]);
      ui.notify(saved.has(button.dataset.save) ? "Maker saved." : "Maker removed from saved list.");
    } catch (error) { ui.notify(readableError(error)); }
    return;
  }
  if (button.dataset.oa) return handleOrderAction(event, button);
  if (button.dataset.quoteSend) return handleQuote(event, button);
  if (button.dataset.action === "pause") {
    event.preventDefault(); event.stopImmediatePropagation();
    const maker = ui.maker(activeUid);
    if (!maker) return ui.notify("Create a maker profile first.");
    try { await api.providers.update({ isPaused: !maker.paused }); ui.notify(maker.paused ? "Your shop is open again." : "New requests paused."); }
    catch (error) { ui.notify(readableError(error)); }
    return;
  }
  if (button.dataset.action === "moved") {
    event.preventDefault(); event.stopImmediatePropagation();
    const maker = ui.maker(activeUid);
    if (!maker) return ui.notify("Create a maker profile first.");
    await relocateShop();
    return;
  }
  if (button.dataset.action === "kyc") {
    event.preventDefault(); event.stopImmediatePropagation();
    ui.notify("KYC is not included in this backend. No ID details were collected or sent.");
  }
}

function deactivateUser() {
  activeUid = null;
  stopLiveData();
  ui.setBackendSession(null);
  ui.setBackendMakers([]);
  ui.setBackendOrders([]);
  ui.setBackendSaved([]);
  setupMessage = "Your Firebase project is connected. Sign in to load live records.";
  ui.setBackendStatus("Firebase ready · sign in", setupMessage);
}

async function handleChange(event) {
  if (!firebaseConfigured || !api) return;
  if (event.target.matches("[data-maker-photo], [data-remove-photo]")) {
    event.preventDefault(); event.stopImmediatePropagation();
    ui.notify("Photo uploads are not in the supplied backend yet. This image was not uploaded or saved.");
  }
}

async function handleOrderAction(event, button) {
  event.preventDefault(); event.stopImmediatePropagation();
  const order = ui.order(button.dataset.id);
  if (!order) return;
  try {
    if (button.dataset.oa === "accept") await api.orders.acceptFixedPrice(order.id);
    else if (button.dataset.oa === "confirm") await api.orders.confirmQuote(order.id);
    else if (button.dataset.oa === "cancel" || button.dataset.oa === "reject-quote") await api.orders.cancel(order.id);
    else if (button.dataset.oa === "reject") {
      const rejectReason = prompt("Why are you declining this request?", "Unavailable on the requested date");
      if (rejectReason === null) return;
      if (!rejectReason.trim()) return ui.notify("Add a short reason before declining.");
      await api.orders.reject({ orderId: order.id, rejectReason: rejectReason.trim() });
    }
    else if (button.dataset.oa === "start") await api.orders.start(order.id);
    else if (button.dataset.oa === "ready") await api.orders.markReady(order.id);
    else if (button.dataset.oa === "collected") await api.orders.markCollected(order.id);
    ui.notify(button.dataset.oa === "reject-quote" ? "Quote declined and request cancelled." : "Order updated securely.");
  } catch (error) { ui.notify(readableError(error)); }
}

async function handleQuote(event, button) {
  event.preventDefault(); event.stopImmediatePropagation();
  const id = button.dataset.quoteSend;
  const price = Number(document.getElementById(`quote-price-${id}`)?.value);
  const time = String(document.getElementById(`quote-eta-${id}`)?.value || "").trim();
  const parsed = time.match(/(\d+(?:\.\d+)?)\s*(minute|min|hour|hr|day)/i);
  if (!Number.isFinite(price) || price <= 0 || !parsed) {
    ui.notify("Enter a positive price and a time such as ‘2 days’ or ‘3 hours’.");
    return;
  }
  const unitWord = parsed[2].toLowerCase();
  const unit = unitWord.startsWith("min") ? "minutes" : unitWord.startsWith("h") ? "hours" : "days";
  try {
    await api.orders.sendQuote({ orderId: id, quotePrice: price, quoteTime: { value: Number(parsed[1]), unit } });
    ui.notify("Quote sent to the customer.");
  } catch (error) { ui.notify(readableError(error)); }
}

async function relocateShop() {
  if (!navigator.geolocation) return ui.notify("Location is not available in this browser.");
  navigator.geolocation.getCurrentPosition(async (position) => {
    try {
      await api.providers.update({ lat: position.coords.latitude, lng: position.coords.longitude, relocate: true });
      ui.notify("Your new shop pin is saved.");
    } catch (error) { ui.notify(readableError(error)); }
  }, () => ui.notify("Allow location access to update the maker pin."), { enableHighAccuracy: true, timeout: 12000 });
}

function getCurrentLocation(button, successMessage) {
  if (!navigator.geolocation) return ui.notify("Location is not available in this browser.");
  button.disabled = true;
  navigator.geolocation.getCurrentPosition((position) => {
    currentLocation = { lat: position.coords.latitude, lng: position.coords.longitude };
    const form = button.closest("form");
    if (form) {
      const lat = form.querySelector('[name="latitude"]');
      const lng = form.querySelector('[name="longitude"]');
      if (lat) lat.value = currentLocation.lat;
      if (lng) lng.value = currentLocation.lng;
      const hint = form.querySelector("[data-location-hint]");
      if (hint) hint.textContent = `Shop pin ready · ${currentLocation.lat.toFixed(4)}, ${currentLocation.lng.toFixed(4)}`;
    }
    if (button.dataset.action === "location") button.textContent = "⌖ Current location set";
    refreshMakers();
    ui.notify(successMessage);
    button.disabled = false;
  }, () => {
    ui.notify("Allow location access in the browser to set a real map pin.");
    button.disabled = false;
  }, { enableHighAccuracy: true, timeout: 12000 });
}

function installFormEnhancements() {
  const makerForm = document.querySelector('form[data-form="maker"]');
  if (makerForm && !makerForm.dataset.backendFields) {
    makerForm.dataset.backendFields = "yes";
    const locationField = makerForm.querySelector(".location-field");
    if (locationField) {
      const hidden = document.createElement("span");
      hidden.innerHTML = '<input type="hidden" name="latitude"><input type="hidden" name="longitude"><small data-location-hint class="muted">The exact coordinates are saved privately with your shop profile.</small>';
      locationField.append(hidden);
    }
    const fields = document.createElement("div");
    fields.className = "formgrid backend-maker-fields";
    fields.innerHTML = '<label class="field"><span>Approximate time for this service</span><input name="avgTime" type="number" min="0.1" step="0.1" value="1" required></label><label class="field"><span>Time unit</span><select name="unit"><option value="hours">Hours</option><option value="minutes">Minutes</option><option value="days">Working days</option></select></label><label class="field"><span>Opening time</span><input name="open" type="time" value="09:00" required></label><label class="field"><span>Closing time</span><input name="close" type="time" value="18:00" required></label><fieldset class="field full"><legend>Working days</legend><div class="backend-days"><label><input type="checkbox" name="openDays" value="0"> Sun</label><label><input type="checkbox" name="openDays" value="1" checked> Mon</label><label><input type="checkbox" name="openDays" value="2" checked> Tue</label><label><input type="checkbox" name="openDays" value="3" checked> Wed</label><label><input type="checkbox" name="openDays" value="4" checked> Thu</label><label><input type="checkbox" name="openDays" value="5" checked> Fri</label><label><input type="checkbox" name="openDays" value="6" checked> Sat</label></div></fieldset><p class="notice compact full">Your service description and photos are not part of this backend. Only its supported shop details, rate, time, location, hours and worker count will be saved.</p>';
    locationField.insertAdjacentElement("afterend", fields);
  }
  const orderForm = document.querySelector('form[data-form="order"]');
  if (orderForm && !orderForm.querySelector('[name="materialsBy"]')) {
    const field = document.createElement("label");
    field.className = "field";
    field.innerHTML = '<span>Who provides the materials?</span><select name="materialsBy"><option>Customer</option><option>Maker</option></select>';
    orderForm.querySelector('[name="service"]')?.closest("label")?.insertAdjacentElement("afterend", field);
  }
}

function installUiEnhancements() {
  installFormEnhancements();
  if (!firebaseConfigured) return;
  const auth = document.getElementById("auth");
  if (!auth) return;
  auth.querySelectorAll("[data-demo]").forEach((button) => { button.hidden = true; });
  auth.querySelectorAll("input[name=\"email\"]").forEach((input) => {
    if (input.value === "customer@demo.local") input.value = "";
  });
  auth.querySelectorAll("input[name=\"password\"]").forEach((input) => {
    if (input.value === "demo1234") input.value = "";
  });
  auth.querySelectorAll("small.muted").forEach((note) => {
    if (note.textContent.includes("Demo only")) note.textContent = "Use the email and password for your Firebase account.";
  });
}

function showSetupPanel() {
  const configReady = !!api;
  const content = `<div class="modalhead"><div><div class="eyebrow">FIREBASE CONNECTION</div><h2>Database setup</h2></div><button class="close" onclick="closeModal()" aria-label="Close">×</button></div><div class="status-card"><span class="status-dot"></span><div><b>${configReady ? "Connected to Firebase" : "Firebase project details needed"}</b><small>${escapeHtml(setupMessage)}</small></div></div>${configReady ? '<div class="notice"><b>Live backend features</b><p>Email sign-in, maker discovery, rates, location, orders, queue estimates, saved makers and verified reviews use Firebase.</p></div>' : '<ol class="setup-steps"><li>Create a Firebase project and register a Web app.</li><li>Open <code>firebase-config.js</code> in this GitHub project.</li><li>Copy the Web app values from Firebase Console into that file.</li><li>Deploy the supplied Firestore rules, indexes and Cloud Functions.</li></ol>'}<div class="collection-list"><div><b>users/{uid}</b><small>Account, phone, language and saved makers</small></div><div><b>providers/{uid}</b><small>Shop, services, hours, queue and rating</small></div><div><b>orders/{orderId}</b><small>Secure request steps and approximate ready times</small></div><div><b>reviews/{reviewId}</b><small>Review after order collection</small></div></div><div class="notice"><b>Not included in this ZIP</b><p>KYC verification and maker photo uploads need separate secure features. Do not upload ID documents or expect photos to be saved yet. A Firebase service-account key must never be placed in the website or GitHub.</p></div><div class="notice"><b>Billing note</b><p>This backend uses Cloud Functions. Deploying those functions requires a Firebase project on the Blaze pay-as-you-go plan with a billing account. Billing setup was not changed.</p></div><a class="btn" target="_blank" rel="noopener" href="https://console.firebase.google.com/">Open Firebase Console ↗</a>`;
  document.getElementById("modal").innerHTML = content;
  document.getElementById("modalbg").classList.add("show");
}

function distanceKm(a, b) {
  if (!Number.isFinite(b.lat) || !Number.isFinite(b.lng)) return null;
  const rad = (x) => x * Math.PI / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

function hash(value) {
  let result = 0;
  for (const letter of value) result = (result * 31 + letter.charCodeAt(0)) | 0;
  return Math.abs(result);
}

function readableError(error) {
  const message = String(error?.message || "Something went wrong.");
  if (message.includes("configuration")) return "Firebase settings are incomplete. Check firebase-config.js.";
  if (message.includes("signed-out")) return "Sign in first to use this feature.";
  if (message.includes("permission-denied")) return "Firebase denied this request. Check your rules and signed-in account.";
  if (message.includes("not-found")) return "A required Firebase record is missing. Check the setup guide.";
  if (message.includes("conflict")) return "This change conflicts with the current order or maker status.";
  if (message.includes("unavailable")) return "Firebase is unavailable. Check your internet connection and deployment.";
  return message;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}
